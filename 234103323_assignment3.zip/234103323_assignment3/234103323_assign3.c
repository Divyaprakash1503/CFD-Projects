#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
int i,j,m,n;
m=100;//along x direction
n=100;//long y direction
float Re;
printf("\nEnter the value of Reynolds Number\n");
scanf("%f",&Re);
float l=1.0;
float h=1.0;
float dx=l/(m-1);
float dy=h/(n-1);
float b = dx/dy;
float oldstrm[m][n],strm[m+1][n+1],w[m][n],oldw[m+1][n+1],u[m][n],v[m][n];
int iterration = 0;
float strmerror,werror;
strmerror=0;
werror = 0;
float dxsq,dysq,constant;
dxsq = pow(dx,2);
dysq = pow(dy,2);
constant = 2*((1/dxsq)+(1/dysq));
FILE *file1= fopen("Stream_Error_400.dat","w");

for(i=1;i<=m;i++)//BOUNDRY CONDITIONS FOR U
	{
	for(j=1;j<=n;j++)
	{
	if(j == n)
	{
	u[i][n] = 1.0;
	}
		else
		{
		u[i][j] = 0.0;
		}
	}
	}
	for(i=1;i<=m;i++)//BOUNDRY CONDITIONS FOR V,STREAM FUNCTION,vorticity
	{
	for(j=1;j<=n;j++)
		{

		v[i][j] = 0.0;
		strm[i][j] = 0.0;

		if (j == 1)  //bottom BC
		{
		w[i][j] = 0;
		}
		else if (j == n)  //top bc
			{

			w[i][n]=(-2*u[i][n])/dy;
			}
		else if (i == 1) //left bc
				{

				w[i][j] = 0;
				}
		else if (i == m)
				{

				w[i][j] = 0; //right bc
				}
		else
			{

			w[i][j]= 0.0;//internal pts
			}

			}
	}


	//iteration loop
	for(iterration=1;iterration<=7000;iterration++)
	{
		for(i=1;i<=m;i++)
		{
			for(j=1;j<=n;j++)//storing data points
			{
				oldstrm[i][j] = strm[i][j];
				oldw[i][j] = w[i][j];
			}
		}

		for(j=2;j<n;j++)
		{
			for(i=2;i<m;i++)
			{


				strm[i][j] = (((strm[i+1][j]+strm[i-1][j])/dxsq)+((strm[i][j+1]+strm[i][j-1])/dysq) + w[i][j])/constant;

				strmerror = strmerror + pow((strm[i][j] - oldstrm[i][j]),2);


			}
		}


		for(j=2;j<n;j++)
		{
			for(i=2;i<n;i++)
			{
			u[i][j] = (strm[i][j+1] - strm[i][j-1])/(2*dy);
				v[i][j] = (strm[i-1][j] - strm[i+1][j])/(2*dx);

				w[i][j]=(Re/constant)*(((w[i+1][j]+w[i-1][j])/(dxsq*Re)) + ((w[i][j+1]+w[i][j-1])/(dysq*Re))
				-((u[i][j]*(w[i+1][j]-w[i-1][j])/(2*dx)) +(v[i][j]*(w[i][j+1]-w[i][j-1])/(2*dy))));

			werror = werror + pow((w[i][j] - oldw[i][j]),2);




			}
		}

		strmerror =sqrt(fabs(strmerror))/((m-2)*(n-2));
		werror =sqrt(fabs(werror))/((m-2)*(n-2));



		printf("Iteration %d\t",iterration);
		printf("Stream_Error %.10f\tw_Error %.10f\n",strmerror,werror);
		fprintf(file1, "%d\t%.10f\t%.10f\n",iterration,strmerror,werror);




		for(j=1;j<=n;j++)//updating bc for vorticity
	{
	for(i=1;i<=m;i++)
		{

		if (j == n)  //top
		{
		w[i][j]=-2*(strm[i][n-1]-strm[i][n]+(u[i][j]*dy))/dysq;

		}
		else if (i == m)  //right
			{
			w[i][j]=-2*(strm[m-1][j]-strm[m][j])/dxsq;

			}
		else if (j == 1) //bottom
				{
				 w[i][j]=-2*(strm[i][2]-strm[i][0])/dysq;

				}
		else if (i == 1)//left
				{
				w[i][j]=-2*(strm[2][j]-strm[1][j])/dxsq;

				}


			}
	}

	 if(strmerror < pow(10,-6) && werror < pow(10,-6))

	 {
	     break;

	 }
	 }
	fclose(file1);

for(j=2;j<n;j++)//updating velocities
			{
			for(i=2;i<m;i++)
				{
				  u[i][j]=(strm[i][j+1]-strm[i][j-1])/(2*dy);
        	                   v[i][j]=(strm[i-1][j]-strm[i+1][j])/(2*dx);
				}
				}

FILE *fp2;
fp2=fopen("400_Stream.plt","w");
fprintf(fp2,"VARIABLES = \"X\", \"Y\", \"PHI\"\n");
fprintf(fp2,"ZONE T = \"BLOCK1\", I = 100, J = 100, F = POINT\n\n");
for(int i=1;i<=m;i++){
	for(int j=1;j<=n;j++){
		fprintf(fp2,"%1f \t %1f \t %1f \n",i*dx,j*dy,strm[i][j]);}
		}

FILE *fp3;
fp3=fopen("400_Vorticity.plt","w");
fprintf(fp3,"VARIABLES = \"X\", \"Y\", \"W\"\n");
fprintf(fp3,"ZONE T = \"BLOCK1\", I = 100, J = 100, F = POINT\n\n");
for(int i=1;i<=m;i++){
	for(int j=1;j<=n;j++){
		fprintf(fp3,"%1f \t %1f \t %1f \n",i*dx,j*dy,w[i][j]);}
		}

FILE *fu;
fu=fopen("Velocity_400.dat","w");

for(i=1;i<=m;i++){
	for(j=1;j<=n;j++){
		fprintf(fu,"%f \t %f \t %f \t %f\n",i*dx,j*dy,u[i][j],v[i][j]);}
		}


FILE *fa;
fa = fopen("re_400_ucenterline.dat","w");
for( j = 1;j<=n;j++)
{
fprintf(fa,"%f \t%f \n",u[(m-1)/2][j],j*dy);
}
FILE *fb;
fb = fopen("re_400_vcenterline.dat","w");
for( i = 1;i<=m;i++)
{
fprintf(fb,"%f \t%f \n",v[i][(n-1)/2],i*dx);
}
}
